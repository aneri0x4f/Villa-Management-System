#include <stdio.h>
#include<math.h>
#include <stdlib.h> 
#include<time.h>
#include<dos.h>
#include<windows.h>
#include<unistd.h>
 
 
 COORD coord = {0,0}; ///set the cordinate to 0, 0 (top-left corner of window);
void setxy(int x, int y){
    coord.X = x; coord.Y = y; /// X and Y coordinates
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void rectangleMarketting(){
	system("color B");
	int i=0;
	printf("%c",177);
    for(i = 1; i < 180; i++){
        setxy(i, 0);
        printf("%c",177);
    }
    setxy(179,0);
    printf("%c",177);
    for(i = 1; i < 42 ; i++){
        setxy(0, i);
        printf("%c",177);
    }
    setxy(0,41);
    printf("%c",177);
    for(i = 1; i < 180; i++){
        setxy(i, 41);
        printf("%c",177);
    }
    setxy(179,41);
    printf("%c",177);
    for(i = 40; i>0 ; i--){
        setxy(179, i);
        printf("%c",177);
    }
    for(i = 1; i < 180; i++){
        setxy(i,6);
		printf("%c",177);
    }
    
}
    void clearWindowMarketting(){
    int i,j;
    for(i = 84; i < 115; i++){
        for(j = 7; j < 30; j++){
            setxy(i,j);printf(" ");
        	}
    	}
    }
    
    void windowMarketting(){
	rectangleMarketting();
    setxy(80,2);
    //SetColor(35);
    printf("HOTEL FCP");
    //SetColor(17);
    setxy(76,4);
    printf("MARKETTING MANAGMENT");
	}


 
 void djtime()
{
    
    time_t t;   // not a primitive datatype
    time(&t);
    FILE *fp;
    fp=fopen("dj_time.txt","w");
	fprintf(fp,"%s",ctime(&t));
	fclose(fp);
    setxy(80,30);printf("%s", ctime(&t));
}


 
int mainMarketting() 
{ 
	system("cls");
	system("color E");
    SMALL_RECT rect;
    COORD coord;
    coord.X = 200; // Defining our X and
    coord.Y = 50;  // Y size for buffer.
    rect.Top = 0;
    rect.Left = 0;
    rect.Bottom = coord.Y-1; // height for window
    rect.Right = coord.X-1;  // width for window
    HANDLE hwnd = GetStdHandle(STD_OUTPUT_HANDLE); // get handle
    SetConsoleScreenBufferSize(hwnd, coord);       // set buffer size
    SetConsoleWindowInfo(hwnd, TRUE, &rect);// set window size
	windowMarketting();
	long long int t=0,i=0,revnue=0,advert[4],advet[4],a=0,j=0,n=4,opt=0; //Declaring test cases
    float sales=6,num=0;
	long long int upper=18,lower=1,diff=(upper-lower)+1;
	setxy(76,12);printf("Please enter the revenue for add :");scanf("%lld",&revnue);
	//According to analysis by Harvard Business School in 2013 Please read it 
	advert[0]=revnue*.85;
	advert[1]=revnue*.05;
	advert[2]=revnue*.06;
	advert[3]=revnue*.04;
	srand(time(0));
	num=rand()%diff + lower;
		z:
		for(j=0 ; j<n ;j++)
		{
			
			if(j==0)
			{
				
				setxy(5,14);
				printf("Please Enter The Amount generated For Advertisment in TV:  ");scanf("%lld",&advet[j]); //Taking the user input for revnue in Tv
				if(revnue==0)
				{
					setxy(5,15);printf("Select The Option: \n 1.Auto Entry \n 2.Enter Again:  ");
					scanf("%lld",&opt);
					if(opt==1)
					{
					advet[0]=revnue/4;
					advet[1]=revnue/4;
					advet[2]=revnue/4;
					advet[3]=revnue/4;
					break;		
					}
					else if(opt==2)
					{
						goto z;
					}
				}
				else if(advet[j]>revnue)
				{
					system("color C");
					setxy(5,16);printf("You have exceeded the revenue amount,\nplease enter valid entries.");
					goto z;
				}
				else
				{
					revnue=revnue-advet[j];
				}
			}
			else if(j==1)
			{
				
				
				setxy(5,17);printf("Please Enter The Amount generated For Advertisment in Youtube:  ");
				scanf("%lld",&advet[j]); //Taking the user input for revnue in Youtube
				if(revnue==0)
				{
					setxy(5,17);printf("Select The Option: \n 1.Auto Entry 2.Enter Again");scanf("%lld",&opt);
					if(opt==1)
					{
					advet[0]=revnue/4;
					advet[1]=revnue/4;
					advet[2]=revnue/4;
					advet[3]=revnue/4;
					break;		
					}
					else if(opt==2)
					{
						goto z;
					}
				}
				else if(advet[j]>revnue)
				{
					system("color C");
						setxy(5,18);printf("You have exceeded the revenue amount,\nplease enter valid entries.");
						goto z;
				}
				else
				{
					revnue=revnue-advet[j];
				}
			}
			else if(j==2)
			{
				
				setxy(5,19);printf("Please Enter The Amount generated For Advertisment in Social Media:  ");
				scanf("%lld",&advet[j]); //Taking the user input for revnue in Social media
				if(revnue==0)
				{
					setxy(5,20);printf("Select The Option: \n 1.Auto Entry 2.Enter Again");
					scanf("%lld",&opt);
					if(opt==1)
					{
					advet[0]=revnue/4;
					advet[1]=revnue/4;
					advet[2]=revnue/4;
					advet[3]=revnue/4;
					break;		
					}
					else if(opt==2)
					{
						goto z;
					}
				}
				else if(advet[j]>revnue)
				{
					system("color C");
					setxy(81,21);printf("SORRY:You have exceeded the revenue amount,\nplease enter valid entries.\n");
					goto z;
				}
				else
				{
					revnue=revnue-advet[j];
				}
			}
			else if(j==3)
			{
				
				setxy(5,22);printf("Please Enter The Amount generated For Advertisment in Newspaper:  ");
				scanf("%lld",&advet[j]); //Taking the user input for revnue in Newspaper
				
				if(revnue==0)
				{
					setxy(5,23);printf("Select The Option: \n 1.Auto Entry 2.Enter Again");
					scanf("%lld",&opt);
					if(opt==1)
					{
					advet[0]=revnue/4;
					advet[1]=revnue/4;
					advet[2]=revnue/4;
					advet[3]=revnue/4;
					break;		
					}
					else if(opt==2)
					{
						goto z;
					}
				}
				else if(advet[j]>revnue)
				{
					system("color C");				
					setxy(81,24);printf("You have exceeded the revenue amount,\nplease enter valid entries.");
					goto z;
				}
				else
				{
					revnue=revnue-advet[j];
				}
			}
		}
		for(j=0 ; j<n ;j++)
		{
			if(advet[j]==advert[j])
			{
				a++;
			}
		}
		if(a==4) // If it matches with analysis of Harvard then it will be 25% 
		{
			sales=sales+sales*.25;
		}
		else if(a!=4) //else according to harvard it ranges form 1% to 12% it can be anything we may believe computer can think himself about market and set any limit 
		{
			num=num/100;
			sales=sales+sales*num;
		}		
	
	    //system("cls");
	    //printf("There is no revenue invested.");
	    FILE *fp; 
	    fp=fopen("dj_d.txt","w");
		fprintf(fp,"%f",sales);
		fclose(fp);	
		setxy(76,28);printf("The company has %.02f%% sales\n",sales);
		djtime();
		printf("Taking you back to login page");
		main();
		sleep(2);
		return 0; 

}




// So the remmaning thing is file I/O in this programme which i will add soon 
