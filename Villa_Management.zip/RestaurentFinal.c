#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include<time.h>
#include <windows.h>


COORD coord = {0,0}; ///set the cordinate to 0, 0 (top-left corner of window);
void setxy(int x, int y){
    coord.X = x; coord.Y = y; /// X and Y coordinates
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}


struct rest{
	int array[75];
	int rate[38];
	int qty;
	int arr_qty[75];
	int y;
	int c;
	int final;
	int total_array[8];
};

struct rest dj;

void rectangleRestaurent(){
	int i=0;
	printf("%c",177);
    for(i = 1; i < 180; i++){
        setxy(i, 0);
        printf("%c",177);
    }
    setxy(179,0);
    printf("%c",177);
    for(i = 1; i < 42 ; i++){
        setxy(0, i);
        printf("%c",177);
    }
    setxy(0,41);
    printf("%c",177);
    for(i = 1; i < 180; i++){
        setxy(i, 41);
        printf("%c",177);
    }
    setxy(179,41);
    printf("%c",177);
    for(i = 40; i>0 ; i--){
        setxy(179, i);
        printf("%c",177);
    }
    
    for(i = 40; i>6 ; i--){
        setxy(100, i);
        printf("%c",177);
    }
    
    
    for(i = 1; i < 178; i++){
        setxy(i,6);
		printf("%c",177);
    }
    
}
    void clearWindowRestaurent(){
    int i,j;
    for(i = 84; i < 115; i++){
        for(j = 7; j < 30; j++){
            setxy(i,j);printf(" ");
        	}
    	}
    }
    
    void windowRestaurent(){
    system("color E");
	rectangleRestaurent();
    setxy(87,2);
    //SetColor(35);
    printf("HOTEL FCP");
    //SetColor(17);
    
    setxy(87,4);
    printf("RESTAURANT");
    
    setxy(38,7);
    printf("MENU");
    
    setxy(140,7);
    printf("Order");
	}
	
	void printmenu()
	{
		setxy(4,10);
		printf("*Chinese: \t\t\tPrice");
		
		setxy(4,12);
		printf("1.Hot & Sour Soup: \t\t80");
		dj.rate[1]=80;
		
		setxy(4,13);
		printf("2.Hakka Noodles: \t\t150");
		dj.rate[2]=150;
		
		setxy(4,14);
		printf("3.Chilly Manchurian dry: \t170");
		dj.rate[3]=170;
		
		setxy(4,15);
		printf("4.Panner Chilly Dry: \t190");
		dj.rate[4]=190;
		
		setxy(4,16);
		printf("5.Chilly Machurian Gravvy: \t280");
		dj.rate[5]=280;
		
		setxy(48,10);
		printf("*Indian: \t\t\tPrice");
		setxy(48,12);
		printf("6.Panner Tikka: \t\t180");
		dj.rate[6]=180;
		setxy(48,13);
		printf("7.Veg Handi: \t\t\t140");
		dj.rate[7]=140;
		setxy(48,14);
		printf("8.Veg Palak Panner: \t\t160");
		dj.rate[8]=160;
		setxy(48,15);
		printf("9.Panner handi Dry: \t\t200");
		dj.rate[9]=200;
		setxy(48,16);
		printf("10.Mix Veg : \t\t\t270");
		dj.rate[10]=270;
		
		setxy(4,19);
		printf("*Starters: \t\t\tPrice");
		setxy(4,21);
		printf("11.Spring Roll: \t\t380");
		dj.rate[11]=380;
		setxy(4,22);
		printf("12.Veg Barbeque: \t\t350");
		dj.rate[12]=350;
		setxy(4,23);
		printf("13.Sizllers: \t\t370");
		dj.rate[13]=370;
		setxy(4,24);
		printf("14.Panner: \t\t\t290");
		dj.rate[14]=290;
		setxy(4,25);
		printf("15.Chilly Panini: \t\t240");
		dj.rate[15]=240;
		
		setxy(4,28);
		printf("*Thai: \t\t\tPrice");
		setxy(4,30);
		printf("16.Guay Teow: \t\t220");
		dj.rate[16]=220;
		setxy(4,31);
		printf("17.Tom Yum Goong: \t\t212");
		dj.rate[17]=212;
		setxy(4,32);
		printf("18.Som Tam: \t\t213");
		dj.rate[18]=213;
		setxy(4,33);
		printf("19.Yam Pla Dook Foo: \t216");
		dj.rate[19]=216;
		setxy(4,34);
		printf("20.Laab: \t\t\t217");
		dj.rate[20]=217;
		
		setxy(48,19);
		printf("*Mexican: \t\t\tPrice");
		setxy(48,21);
		printf("21.Pozole: \t\t\t580");
		dj.rate[21]=580;
		setxy(48,22);
		printf("22.Tacos Al Postor: \t\t460");
		dj.rate[22]=460;
		setxy(48,23);
		printf("23.Elote: \t\t\t490");
		dj.rate[23]=217;
		setxy(48,24);
		printf("24.Mole: \t\t\t450");
		dj.rate[24]=217;
		setxy(48,25);
		printf("25.Toastadas: \t\t\t440");
		dj.rate[25]=217;
		
		setxy(48,28);
		printf("*Italian: \t\t\tPrice");
		setxy(48,30);
		printf("26.Arancini: \t\t\t380");
		dj.rate[26]=380;
		setxy(48,31);
		printf("27.Lasagene: \t\t\t500");
		dj.rate[27]=500;
		setxy(48,32);
		printf("28.Pizza: \t\t\t470");
		dj.rate[28]=470;
		setxy(48,33);
		printf("29.Pasta: \t\t\t590");
		dj.rate[29]=590;
		setxy(48,34);
		printf("30.Gelato: \t\t\t480");
		dj.rate[30]=480;
	}
	
	void order()
	{
		int i=-1,j=8;
		dj.final=0;
		while(1)
		{
		i=i+1;
		j=j+3;
		setxy(128,j);
		fflush(stdin);
		printf("Please enter Your Choice: ");
		scanf("%d",&dj.array[i]);
		dj.final=dj.final+1;
		setxy(128,j+1);
		printf("Please enter the qty: ");
		scanf("%d",&dj.arr_qty[i]);
		setxy(128,j+2);
		printf("1. Add a dish  2.Get bill ");
		scanf("%d",&dj.y);
		if(dj.y==2)
		{
			break;
		}
		}
	}
	
void modrectangleRestaurent(){
	system("color B");
	int i=0;
	printf("%c",177);
    for(i = 1; i < 180; i++){
        setxy(i, 0);
        printf("%c",177);
    }
    setxy(179,0);
    printf("%c",177);
    for(i = 1; i < 42 ; i++){
        setxy(0, i);
        printf("%c",177);
    }
    setxy(0,41);
    printf("%c",177);
    for(i = 1; i < 180; i++){
        setxy(i, 41);
        printf("%c",177);
    }
    setxy(179,41);
    printf("%c",177);
    for(i = 40; i>0 ; i--){
        setxy(179, i);
        printf("%c",177);
    }    
    for(i = 1; i < 180; i++){
        setxy(i,6);
		printf("%c",177);
    }
     
}

 void modwindowRestaurent(){
    setxy(87,2);
    //SetColor(35);
    printf("HOTEL FCP");
    //SetColor(17);
    
    setxy(87,4);
    printf("RESTAURANT");
	}
	



void djtime()
{
    
    time_t t;   // not a primitive datatype
    time(&t);
    setxy(150,2);printf("%s", ctime(&t));
}

void modtime()
{
    
    time_t t;   // not a primitive datatype
    time(&t);
    setxy(136,11);printf("%s", ctime(&t));
}




	
void bill()
{
	
	int i=0;
	for(i=25; i<160;i++)
	{
	setxy(i,10);printf("=");	
	}
	for(i=25; i<160;i++)
	{
	setxy(i,14);printf("=");	
	}
	for(i=25; i<160;i++)
	{
	setxy(i,38);printf("=");	
	}
	setxy(87,11);
    printf("HOTEL FCP");
    modtime();	
	setxy(25,13);printf("ITEMS");
	setxy(75,13);printf("RATE");
	setxy(95,13);printf("QTY");
	setxy(115,13);printf("TAXES");
	setxy(135,13);printf("DICOUNT");
	setxy(155,13);printf("TOTAL");
	i=0;
	do
	{
		
		int j=14;
		j=j+1;
	
			
			if(dj.array[i]==1)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Hot & Sour Soup");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.total_array[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			fflush(stdin);
			if(dj.array[i]==2)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Hakka Noodles:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",(dj.rate[dj.array[i]]*dj.arr_qty[i]));
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			if(dj.array[i]==3)
			{
				dj.total_array[i]=(dj.rate[dj.arr_qty[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Chilly Manchurian dry:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",(dj.rate[dj.array[i]]*dj.arr_qty[i]));
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}				
			}
			if(dj.array[i]==4)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Panner Chilly Dry:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",(dj.rate[dj.array[i]]*dj.arr_qty[i]));
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			if(dj.array[i]==5)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Chilly Machurian Gravvy:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==6)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Panner Tikka:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			
			if(dj.array[i]==7)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Veg Handi:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			
			if(dj.array[i]==8)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Veg Palak Panner:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==9)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Panner handi Dry:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==10)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Mix Veg:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==11)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Spring Roll:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==12)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Veg Barbeque:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			if(dj.array[i]==13)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Sizllers:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			
			if(dj.array[i]==14)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Panner");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			
			if(dj.array[i]==15)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Chilly Panini:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==16)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Guay Teow:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==17)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Tom Yum Goong:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==18)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Som Tam:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==19)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Yam Pla Dook Foo:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==20)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Laab:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==21)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Pozole:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==22)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Tacos Al Postor:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==23)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Elote:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==24)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Mole:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==25)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Toastadas:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==26)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Arancini:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==27)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Lasagene:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==28)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Pizza:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==29)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Pasta:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
			
			if(dj.array[i]==30)
			{
				dj.total_array[i]=(dj.rate[dj.array[i]]*dj.arr_qty[i]);
				setxy(25,j);printf("Gelato:");setxy(75,j);printf("%d",dj.rate[dj.array[i]]);setxy(95,j);printf("%d",dj.arr_qty[i]);setxy(115,j);printf("5%%");setxy(135,j);printf("0");setxy(155,j);printf("%d",dj.rate[dj.array[i]]*dj.arr_qty[i]);
				for(i=25; i<160;i++){
				setxy(i,j+1);printf("=");	
				}
			}
	i=i+1;
			
	}while(i<dj.final);
	int total=0,temp=0;
	for(i=25; i<160;i++){
				setxy(i,36);printf("=");	
				}
	setxy(26,37);printf("TOTAL(INCLUSIVE OF ALL TAXES)");	
	for(i=0 ; i<dj.final ;i++)
	{
		total=total+dj.total_array[i];
	}
	
	total=total+total*.05;
	
	if(total>5000)
	{
		setxy(135,15);printf("50%%");
		total=total-total*.5;
	}
	
	setxy(155,37);printf("%d",total);
}



void debug()
{
	setxy(89,43);printf("%d",dj.final);
	
	printf("%d",dj.array[1]);
}
	
	
       
int main(){
	int i=0;
	SMALL_RECT rect;
    COORD coord;
    coord.X = 200; // Defining our X and
    coord.Y = 50;  // Y size for buffer.
    rect.Top = 0;
    rect.Left = 0;
    rect.Bottom = coord.Y-1; // height for window
    rect.Right = coord.X-1;  // width for window
    HANDLE hwnd = GetStdHandle(STD_OUTPUT_HANDLE); // get handle
    SetConsoleScreenBufferSize(hwnd, coord);       // set buffer size
    SetConsoleWindowInfo(hwnd, TRUE, &rect);// set window size
	rectangleRestaurent();
	
	for(i=0 ; i<75 ; i++)
	{
	dj.array[i]=0;	
	}
	for(i=0 ; i<8 ; i++)
	{
	dj.total_array[i]=0;	
	}	
	windowRestaurent();
	djtime();
	printmenu(); 
	order();
	system("cls");
	modrectangleRestaurent();
	modwindowRestaurent();
	djtime();
	bill();
	debug();
	getch();
}
