#include <stdio.h>
#include<conio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>

/*COORD coord = {0,0}; ///set the cordinate to 0, 0 (top-left corner of window);
void setxy(int x, int y){
    coord.X = x; coord.Y = y; /// X and Y coordinates
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}*/

void rectangleSales(){
	int i=0;
	printf("%c",177);
    for(i = 1; i < 180; i++){
        setxy(i, 0);
        printf("%c",177);
    }
    setxy(179,0);
    printf("%c",177);
    i=0;
    for(i = 1; i < 42 ; i++){
        setxy(0, i);
        printf("%c",177);
    }
    setxy(0,41);
    printf("%c",177);
    for(i = 1; i < 180; i++){
        setxy(i, 41);
        printf("%c",177);
    }
    setxy(179,41);
    printf("%c",177);
    for(i = 40; i>0 ; i--){
        setxy(179, i);
        printf("%c",177);
    }
    for(i = 1; i < 180; i++){
        setxy(i,6);
		printf("%c",177);
    }
    for(i = 7; i < 41; i++){
        setxy(80,i);
        printf("%c",177);
    }
}
    void clearWindowSales(){
    int i,j;
    for(i = 84; i < 156; i++){
        for(j = 7; j < 40; j++){
            setxy(i,j);printf(" ");
        	}
    	}
    }
	
	void print_headingSales(const char st[]){
    //SetColorAndBackground(31,28);
    setxy(87,11);
	printf("HSS : %s",st);
    //SetColorAndBackground(17,15);
	}
	
	
	void sales_sub_window(){
    setxy(89,2);
    //SetColor(35);
    printf("HOTEL FCP");
    //SetColor(17);
    
    setxy(87,4);
    printf("SALES MANAGMENT");
	}
	

void getsales()
{
	float sales;
	char c;
	clearWindowSales();
	print_headingSales("Sales Data");
	FILE *fp,*hj;
    fp = fopen("dj_d.txt","r");
    hj=fopen("dj_time.txt","r");
    fscanf(fp,"%f",&sales);
	setxy(87,14);printf("Sales Generated in Marketting: %f%%",sales);
    setxy(87,16);printf("Date of Generation of Sales from Marketting: ");
    c = fgetc(hj);
    while (c != EOF) 
    { 
        printf ("%c", c); 
        c = fgetc(hj); 
    }
    setxy(87,18);printf("Sales Lost or Gain Customer Satisfaction:Work Pending  ");
    setxy(87,20);printf("Date of Generation of Sales from Customer Satisfaction: Work Pending ");
	fclose(fp); 
	fclose(hj);  
}

void lostsales()
{
	clearWindowSales();
	print_headingSales("Loss in Sales Data");
	setxy(87,14);printf("Sales Lost or Gain Customer Satisfaction:Work Pending  ");
    setxy(87,16);printf("Date of Generation of Sales from Customer Satisfaction: Work Pending ");		
}

void increaseSales()
{
	float sales;
	char c;	
	clearWindowSales();
	print_headingSales("Increase in Sales Data");
	FILE *fp,*hj;
    fp = fopen("dj_d.txt","r");
    hj=fopen("dj_time.txt","r");
    fscanf(fp,"%f",&sales);
	setxy(87,14);printf("Sales Generated in Marketing: %f%%",sales);
    setxy(87,16);printf("Date of Generation of Sales from Marketing: ");
    c = fgetc(hj);
    while (c != EOF) 
    { 
        printf ("%c", c); 
        c = fgetc(hj); 
    }
    setxy(87,18);printf("Proper Way Of marketing can generate a descent amount of Sales ");
	setxy(87,20);printf("Sales Lost or Gain Customer Satisfaction:Work Pending  ");
    setxy(87,22);printf("Date of Generation of Sales from Customer Satisfaction: Work Pending ");
	setxy(87,24);printf("Waiting for 300 records");
	fclose(fp); 
	fclose(hj);
}

void suggestions()
{
    clearWindowSales();
	print_headingSales("Suggestions");
	setxy(87,14);printf("Customer should always be cared");
    setxy(87,16);printf("Proper Marketing needed");	
}


void sales_window(){
    int choice;
    //SetColor(28);
    int x = 2;
    while(1){
        setxy(x,8);printf("1. View Sales Status");
        setxy(x,10);printf("2. Loss in Sales");
        setxy(x,12);printf("3. Gain in Sales");
        setxy(x,14);printf("4. Suggestions");
        setxy(x,16);printf("5. Exit");
        setxy(x,18);printf("Enter your choice: ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                getsales();
                break;
            case 2:
                lostsales();
                break;
            case 3:
                increaseSales();
                break;
            case 4:
                suggestions();
				break;
            case 5:
            	
            	main();
                exit(0);
                break;
            default:
                break;
        }

    }

}



int mainSales()
{
	system("cls");
	system("color E");
	SMALL_RECT rect;
    COORD coord;
    coord.X = 200; // Defining our X and
    coord.Y = 50;  // Y size for buffer.
    rect.Top = 0;
    rect.Left = 0;
    rect.Bottom = coord.Y-1; // height for window
    rect.Right = coord.X-1;  // width for window
    HANDLE hwnd = GetStdHandle(STD_OUTPUT_HANDLE); // get handle
    SetConsoleScreenBufferSize(hwnd, coord);       // set buffer size
    SetConsoleWindowInfo(hwnd, TRUE, &rect);// set window size
    rectangleSales();
    sales_sub_window();
 	sales_window();
 	main();
    getch();
	
}
