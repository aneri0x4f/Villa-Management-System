#include<stdio.h>
#include<string.h>
#include<windows.h>
#include<conio.h>
char bookRoomA(char s[]);
char bookRoomB(char s[]);
char bookRoomC(char s[]);
void thankyou();
void setxy(int x,int y);
void custDetEntry();
struct custDet
{
	char name[10];
	char surname[10];
	int noDays;
};
struct custDet cd;
int main()
{

	FILE *roomA;
	FILE *roomB;
	FILE *roomC;
	int choice;
	int roomType,y,i;
	char c,roomFinal[6];
	system("color B");
	printf("\t\t\t\t\t");
	printf("**************\n\t\t\t\t\t  MAIN MENU\n\t\t\t\t\t**************");
	printf("\n\n\nEnter 1 to book a room \n");
	scanf("%d",&choice);
	a:
	//custDetEntry();

	if(choice==1)
	{
		system("cls");
		system("color B");
		printf("What room category you want to book?\n\n\n1. A category\n\tSuit with terrace\n\tKing size bed\n\tPer room price Rs26,000\n\n\n2. B category\n\tTwin room\n\t2 Single beds\n\tPer room price Rs23,000\n\n\n3. C category\n\tSuite with balcony\n\t1 double bed\n\tPer room price Rs20,000");
		scanf("%d",&roomType);
		system("cls");
		system("color B");
		if(roomType==1)
		{
			//borders
			for(i=0;i<60;i++)
			{
				printf("%c",177);
			}
			for( i=1;i<17;i++)
			{
				
				setxy(59,i);
				printf("%c",177);
			}
		
		/*	for(i=0;i<17;i++)
			{
				setxy(0,i);
				printf("%c",177);
			}
		*/	
			setxy(5,1);
			//printing the rooms available
			printf("\nFollowing rooms are available:\n");
			roomA=fopen("roomA.txt","r");
			while((c=fgetc(roomA))!=EOF)
			{
				printf("%c",c);
			}
			printf("\n");
			//borders
			setxy(0,17);
			for(i=0;i<60;i++)
			{
				printf("%c",177);
			}
			//asking for room choice
			printf("\nPlease enter the room number you want to book:\n");
			scanf("%s",roomFinal);
			fclose(roomA);
			bookRoomA(roomFinal);
			printf("\nDo you want to continue booking next room?\n1.YES\n2.NO\n");
			scanf("%d",&y);
			if(y==1)
			{
				goto a;
			}
			else if (y==2)
			{
				system("color A");
				
				thankyou();
			}
		}
		else if(roomType==2)
		{
			printf("\nFollowing rooms are available:\n");
			roomB=fopen("roomB.txt","r");
			while((c=fgetc(roomB))!=EOF)
			{
				printf("%c",c);
			}
			printf("\nPlease enter the room number you want to book:");
			scanf("%s",roomFinal);
			fclose(roomB);
			bookRoomB(roomFinal);
			printf("\nDo you want to continue booking next room?\n1.YES\n2.NO");
			scanf("%d",&y);
			if(y==1)
			{
				goto a;
			}
			else if (y==2)
			{
				system("color A");
			//	bill();
				thankyou();
			}
			
		}
		else if(roomType==3)
		{
			printf("Following rooms are available:");
			roomC=fopen("roomC.txt","r");
			while((c=fgetc(roomC))!=EOF)
			{
				printf("%c",c);
			}
			printf("\nPlease enter the room number you want to book:");
			scanf("%s",roomFinal);
			fclose(roomC);
			bookRoomC(roomFinal);
			printf("\nDo you want to continue booking next room?\n1.YES\n2.NO");
			scanf("%d",&y);
			if(y==1)
			{
				goto a;
			}
			else if (y==2)
			{
				system("color A");
				thankyou();
			}
		}
	}
	return 0;	
}


char bookRoomA(char s[]){
	int c=0,i,a;
	char k[150],str=' ',*ptr;
	FILE *roomA;
	FILE *temp;
	roomA=fopen("roomA.txt","r");
	temp=fopen("temp.txt","w");
	//standard convert all entered values to upper case
	for (i = 0; s[i]!='\0'; i++) {
	   if(s[i] >= 'a' && s[i] <= 'z') {
	      s[i] = s[i] -32;
	   }
	  
        }
     //k is the value of room  from file  
	while(fgets(k,100,roomA)!=NULL)
	{
		
		//seperating/removing enters using delimeter \n
		//strtok returns a pointer
		ptr=strtok(k,"\n");

		a = strcmp(k,s);
		if(a!=0)
		{
		
			//printing into file
			fprintf(temp,"%s\n",k);
			//setting pointer to next position
			ptr=strtok(k,"\n");
		}
			
		}
		fclose(roomA);
		fclose(temp);
		
		remove("roomA.txt");
		rename("temp.txt","roomA.txt");
		
		return 0;
}
char bookRoomB(char s[]){
	int c=0,i,a;
	char k[150],str=' ',*ptr;
	FILE *roomB;
	FILE *temp;
	roomB=fopen("roomB.txt","r");
	temp=fopen("temp.txt","w");
	//standard convert all entered values to upper case
	for (i = 0; s[i]!='\0'; i++) {
	   if(s[i] >= 'a' && s[i] <= 'z') {
	      s[i] = s[i] -32;
	   }
	  
        }
     //k is the value of room  from file  
	while(fgets(k,100,roomB)!=NULL)
	{
	
		//seperating/removing enters using delimeter \n
		//strtok returns a pointer
		ptr=strtok(k,"\n");

		a = strcmp(k,s);
		if(a!=0)
		{
			//printing into file
			fprintf(temp,"%s\n",k);
			//setting pointer to next position
			ptr=strtok(k,"\n");
		}
			
		}
		fclose(roomB);
		fclose(temp);
		
		remove("roomB.txt");
		rename("temp.txt","roomB.txt");
		
		return 0;
}
char bookRoomC(char s[]){
	int c=0,i,a;
	char k[150],str=' ',*ptr;
	FILE *roomC;
	FILE *temp;
	roomC=fopen("roomC.txt","r");
	temp=fopen("temp.txt","w");
	//standard convert all entered values to upper case
	for (i = 0; s[i]!='\0'; i++) {
	   if(s[i] >= 'a' && s[i] <= 'z') {
	      s[i] = s[i] -32;
	   }
	  
        }
     //k is the value of room  from file  
	while(fgets(k,100,roomC)!=NULL)
	{
		//seperating/removing enters using delimeter \n
		//strtok returns a pointer
		ptr=strtok(k,"\n");

		a = strcmp(k,s);
		if(a!=0)
		{
			//printing into file
			fprintf(temp,"%s\n",k);
			//setting pointer to next position
		
		}
			
		}
		fclose(roomC);
		fclose(temp);
		
		remove("roomC.txt");
		rename("temp.txt","roomC.txt"); 
		return 0;
}

COORD c={0,0};
void setxy(int x,int y)
{
	c.X = x; c.Y = y; // Set X and Y coordinates
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}
void custDetEntry()
{
	FILE *crd;
	crd=fopen("CustomerRoomDet.txt","a");
	
	printf("Enter your first name:");
	scanf("%s",cd.name);
	printf("Enter your last name:");
	scanf("%s",cd.surname);
	printf("enter the number of days to stay:");
	scanf("%d",&cd.noDays);
	printf("%d",cd.noDays);

	fprintf(crd,"%s      %s      %d      ",cd.name,cd.surname,cd.noDays);
	fclose(crd);
}
void thankyou()
{
	int i;
		for(i=0; i<35; i++)
  		{
  			
    		system("color E");
		    setxy(i, 25);
			printf(" THANKYOU FOR CHOOSING VILLA FCP,WISH YOU A HAPPY STAY : )");
            setxy(i-3, 15); //For clearing previous position of arrow
    		

    Sleep(100); 
}
}
