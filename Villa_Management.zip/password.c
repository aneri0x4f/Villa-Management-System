#include<stdio.h>
int main()
{
	char p[10];
	int i;
	for(i=0;i<10;i++)
	{
		p[i]=getch();
		printf("*");
	}
	
		return 0;
}

