struct Tariff
{
	char name[20];
	int empid;
	float salary;
};

int main()
{
	struct Tariff t1,t2,t3;

	printf("Enter your name");
	scanf("%s",t1.name);
	printf("enter empid");
	scanf("%d",&t1.empid);
	printf("enter salary");
	scanf("%f",&t1.salary);
	printf("%s",t1.name);
}
//fwrite is used to usend struct directly to file....
// it creates binary file
// fwrite(&input1,size(mention no of bytes),no of variables,pointer for file);

/*
FILE *OUT
OUT=FOPEN("","w");
if pointr ==null{
	error... no right mode
	fprintf(stderr,"error found");
}
fwrite(&t1 , sizeof(struct tariff) , 3 ,OUT);
fwrite returns 1 when succes put in file else returns 0;


*/
/*
ONLY GIVE REFFERENCE OF METHODS ABOVE MAIN METGOD LIKE:
void someMethod();
int area(int r);
int main(){
	the code;
}

void someMethod()
{
..
..}







fflush(stdin);
when input any int data, \n is stored in buffer so this will clear that;

reading space seprated string
scanf("%[^\n]s",t1.name);

that is untill we press enter it will cont scanning name!!!
*/
